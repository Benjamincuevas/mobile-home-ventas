# 🏡 Mobile Home Ventas

Sitio web de venta de casas móviles (mobile homes) enfocado en generación de clientes por WhatsApp, con diseño tipo marketplace (inspirado en el inventario de Camping World) y panel de administración propio.

## Demo local

```bash
npx serve .
# o: python3 -m http.server 8000
```

## Estructura

| Archivo | Descripción |
|---|---|
| `index.html` | Página pública: inventario con filtros laterales, buscador, carrusel de fotos, ficha de detalles, estimador de pagos y formulario de precalificación. |
| `admin.html` | Panel de administración: alta/edición de casas con fotos, características y toda la ficha del producto. Genera `data.js`. Código de acceso por defecto: `2468`. |
| `data.js` | Datos del inventario y ajustes del negocio (lo genera el panel — no editar a mano). |
| `data.ejemplo.js` | Ejemplo del contrato de datos. |
| `CLAUDE.md` | Contexto del proyecto para Claude Code (arquitectura, reglas, backlog). |
| `LEEME.txt` | Instrucciones de publicación para el dueño del negocio. |

## Flujo de contenido

`admin.html` → editar casas → **Descargar data.js** → subirlo junto a `index.html`. La página lee `window.MHV_DATA` y muestra el inventario real; sin `data.js` usa unidades de muestra ilustradas.

## Publicación con GitHub Pages

Settings → Pages → *Deploy from a branch* → `main` / root. El sitio queda en `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/` y el panel en `.../admin.html`.

## Reglas técnicas

Sin frameworks ni build (hosting estático puro), JavaScript compatible con Safari de iOS antiguo (sin `?.`/`??`), sin `<form>` submit, persistencia por exportación de `data.js`. Detalles completos en `CLAUDE.md`.
